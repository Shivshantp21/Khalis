const express = require('express');
const app = express();
const dotenv = require('dotenv');
const morgan = require('morgan'); 
dotenv.config();

const userRoutes = require('./routes/userRoutes');
const playlistHubRoutes = require('./routes/playlistHubRoutes');
const playlistRoutes = require('./routes/playlistRoutes');
const banniRoutes = require('./routes/banniRoutes');
const shabadRoutes = require('./routes/shabadRoutes');

const sequelize = require('./config/config');


app.use(express.json());
app.use(morgan('dev')); 

app.use('/api/users', userRoutes);
app.use('/api/playlist-hubs', playlistHubRoutes);
app.use('/api/playlists', playlistRoutes);
app.use('/api/bannis', banniRoutes);
app.use('/api/shabads', shabadRoutes);

app.get("/", (req, res) => {
    res.json("Hello, this is the backend!");
});

const PORT = process.env.PORT || 8800;

sequelize.authenticate()
    .then(() => {
        console.log('Database connection established successfully.');
        return sequelize.sync(); 
    })
    .then(() => {
        app.listen(PORT, () => {
            console.log(`Server is running on port ${PORT}`);
        });
    })
    .catch(err => {
        console.error('Unable to connect to the database:', err);
    });

module.exports = app;
