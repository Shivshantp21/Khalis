const User = require('../models/user');

exports.createUser = async (req, res) => {
    try {
        const { username, password, email } = req.body;
        const newUser = await User.create({ username, password, email });
        res.status(201).json(newUser);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getUsers = async (req, res) => {
    try {
        const users = await User.findAll();
        res.status(200).json(users);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

