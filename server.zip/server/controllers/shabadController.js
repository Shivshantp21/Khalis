
const { Shabad } = require('../models');


exports.createShabad = async (req, res) => {
  try {
    const { title, content } = req.body;
    const shabad = await Shabad.create({ title, content });
    res.status(201).json(shabad);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


exports.getAllShabads = async (req, res) => {
  try {
    const shabads = await Shabad.findAll();
    res.json(shabads);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


exports.getShabadById = async (req, res) => {
  try {
    const { id } = req.params;
    const shabad = await Shabad.findByPk(id);
    if (!shabad) {
      return res.status(404).json({ error: 'Shabad not found.' });
    }
    res.json(shabad);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


exports.updateShabad = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, content } = req.body;
    const shabad = await Shabad.findByPk(id);
    if (!shabad) {
      return res.status(404).json({ error: 'Shabad not found.' });
    }
    shabad.title = title || shabad.title;
    shabad.content = content || shabad.content;
    await shabad.save();
    res.json(shabad);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


exports.deleteShabad = async (req, res) => {
  try {
    const { id } = req.params;
    const shabad = await Shabad.findByPk(id);
    if (!shabad) {
      return res.status(404).json({ error: 'Shabad not found.' });
    }
    await shabad.destroy();
    res.json({ message: 'Shabad deleted successfully.' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
