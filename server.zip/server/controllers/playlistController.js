
const { Playlist, PlaylistBanni, PlaylistShabad, Banni, Shabad } = require('../models');


exports.createPlaylist = async (req, res) => {
  try {
    const { playlist_hub_id, name, description, visibility } = req.body;
    const playlist = await Playlist.create({ playlist_hub_id, name, description, visibility });
    res.status(201).json(playlist);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.addBanniToPlaylist = async (req, res) => {
  try {
    const { playlist_id, banni_id, chapter_order } = req.body;

    const playlist = await Playlist.findByPk(playlist_id);
    const banni = await Banni.findByPk(banni_id);
    if (!playlist || !banni) {
      return res.status(404).json({ error: 'Playlist or Banni not found.' });
    }


    const playlistBanni = await PlaylistBanni.create({ playlist_id, banni_id, chapter_order });
    res.status(201).json(playlistBanni);
  } catch (error) {
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({ error: 'Banni already added to this playlist.' });
    }
    res.status(500).json({ error: error.message });
  }
};


exports.addShabadToPlaylist = async (req, res) => {
  try {
    const { playlist_id, shabad_id, chapter_order } = req.body;

    const playlist = await Playlist.findByPk(playlist_id);
    const shabad = await Shabad.findByPk(shabad_id);
    if (!playlist || !shabad) {
      return res.status(404).json({ error: 'Playlist or Shabad not found.' });
    }

    const playlistShabad = await PlaylistShabad.create({ playlist_id, shabad_id, chapter_order });
    res.status(201).json(playlistShabad);
  } catch (error) {
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({ error: 'Shabad already added to this playlist.' });
    }
    res.status(500).json({ error: error.message });
  }
};


exports.getPlaylist = async (req, res) => {
  try {
    const { id } = req.params;
    const playlist = await Playlist.findOne({
      where: { id },
      include: [
        {
          model: Banni,
          as: 'bannis',
          through: {
            attributes: ['chapter_order'],
          },
        },
        {
          model: Shabad,
          as: 'shabads',
          through: {
            attributes: ['chapter_order'],
          },
        },
      ],
    });

    if (!playlist) {
      return res.status(404).json({ error: 'Playlist not found.' });
    }


    const combinedEntries = [
      ...playlist.bannis.map(banni => ({
        type: 'Banni',
        id: banni.id,
        title: banni.title,
        content: banni.content,
        chapter_order: banni.PlaylistBanni.chapter_order,
      })),
      ...playlist.shabads.map(shabad => ({
        type: 'Shabad',
        id: shabad.id,
        title: shabad.title,
        content: shabad.content,
        chapter_order: shabad.PlaylistShabad.chapter_order,
      })),
    ];

    combinedEntries.sort((a, b) => a.chapter_order - b.chapter_order);

    res.json({
      playlist,
      entries: combinedEntries,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.updatePlaylist = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, visibility } = req.body;
    const playlist = await Playlist.findByPk(id);
    if (!playlist) {
      return res.status(404).json({ error: 'Playlist not found.' });
    }

    playlist.name = name || playlist.name;
    playlist.description = description || playlist.description;
    playlist.visibility = visibility || playlist.visibility;
    await playlist.save();

    res.json(playlist);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deletePlaylist = async (req, res) => {
  try {
    const { id } = req.params;
    const playlist = await Playlist.findByPk(id);
    if (!playlist) {
      return res.status(404).json({ error: 'Playlist not found.' });
    }
    await playlist.destroy();
    res.json({ message: 'Playlist deleted successfully.' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
