const { Banni } = require('../models');


exports.createBanni = async (req, res) => {
  try {
    const { title, content } = req.body;
    const banni = await Banni.create({ title, content });
    res.status(201).json(banni);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


exports.getAllBannis = async (req, res) => {
  try {
    const bannis = await Banni.findAll();
    res.json(bannis);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


exports.getBanniById = async (req, res) => {
  try {
    const { id } = req.params;
    const banni = await Banni.findByPk(id);
    if (!banni) {
      return res.status(404).json({ error: 'Banni not found.' });
    }
    res.json(banni);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


exports.updateBanni = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, content } = req.body;
    const banni = await Banni.findByPk(id);
    if (!banni) {
      return res.status(404).json({ error: 'Banni not found.' });
    }
    banni.title = title || banni.title;
    banni.content = content || banni.content;
    await banni.save();
    res.json(banni);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


exports.deleteBanni = async (req, res) => {
  try {
    const { id } = req.params;
    const banni = await Banni.findByPk(id);
    if (!banni) {
      return res.status(404).json({ error: 'Banni not found.' });
    }
    await banni.destroy();
    res.json({ message: 'Banni deleted successfully.' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
