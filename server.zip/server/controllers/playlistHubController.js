const PlaylistHub = require('../models/playlistHub');

exports.createPlaylistHub = async (req, res) => {
    try {
        const { userId, name, isPublic } = req.body;
        const newPlaylistHub = await PlaylistHub.create({ userId, name, isPublic });
        res.status(201).json(newPlaylistHub);
    } catch (err) {
        res.status(500).json({ message: 'Error creating playlist hub', error: err.message });
    }
};

exports.getPlaylistHubs = async (req, res) => {
    try {
        const playlistHubs = await PlaylistHub.findAll();
        res.json(playlistHubs);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching playlist hubs', error: err.message });
    }
};

exports.getPlaylistHubById = async (req, res) => {
    const { id } = req.params;
    try {
        const playlistHub = await PlaylistHub.findByPk(id);
        if (playlistHub) {
            res.json(playlistHub);
        } else {
            res.status(404).json({ message: 'Playlist hub not found' });
        }
    } catch (err) {
        res.status(500).json({ message: 'Error fetching playlist hub', error: err.message });
    }
};

exports.updatePlaylistHub = async (req, res) => {
    const { id } = req.params;
    try {
        const playlistHub = await PlaylistHub.findByPk(id);
        if (playlistHub) {
            await playlistHub.update(req.body);
            res.json(playlistHub);
        } else {
            res.status(404).json({ message: 'Playlist hub not found' });
        }
    } catch (err) {
        res.status(500).json({ message: 'Error updating playlist hub', error: err.message });
    }
};

exports.deletePlaylistHub = async (req, res) => {
    const { id } = req.params;
    try {
        const playlistHub = await PlaylistHub.findByPk(id);
        if (playlistHub) {
            await playlistHub.destroy();
            res.status(204).send();
        } else {
            res.status(404).json({ message: 'Playlist hub not found' });
        }
    } catch (err) {
        res.status(500).json({ message: 'Error deleting playlist hub', error: err.message });
    }
};
