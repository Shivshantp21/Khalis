
const express = require('express');
const router = express.Router();
const banniController = require('../controllers/banniController');


router.post('/', banniController.createBanni);


router.get('/', banniController.getAllBannis);


router.get('/:id', banniController.getBanniById);


router.put('/:id', banniController.updateBanni);


router.delete('/:id', banniController.deleteBanni);

module.exports = router;
