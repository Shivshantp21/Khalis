const express = require('express');
const router = express.Router();
const playlistHubController = require('../controllers/playlistHubController');

router.post('/', playlistHubController.createPlaylistHub);

router.get('/', playlistHubController.getPlaylistHubs);

router.get('/:id', playlistHubController.getPlaylistHubById);

router.put('/:id', playlistHubController.updatePlaylistHub);

router.delete('/:id', playlistHubController.deletePlaylistHub);

module.exports = router;
