const express = require('express');
const router = express.Router();
const shabadController = require('../controllers/shabadController');


router.post('/', shabadController.createShabad);


router.get('/', shabadController.getAllShabads);


router.get('/:id', shabadController.getShabadById);


router.put('/:id', shabadController.updateShabad);


router.delete('/:id', shabadController.deleteShabad);

module.exports = router;
