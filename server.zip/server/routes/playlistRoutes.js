
const express = require('express');
const router = express.Router();
const playlistController = require('../controllers/playlistController');


router.post('/', playlistController.createPlaylist);


router.post('/add-banni', playlistController.addBanniToPlaylist);


router.post('/add-shabad', playlistController.addShabadToPlaylist);

router.get('/:id', playlistController.getPlaylist);


router.put('/:id', playlistController.updatePlaylist);

router.delete('/:id', playlistController.deletePlaylist);

module.exports = router;
