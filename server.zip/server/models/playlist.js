
const { DataTypes } = require('sequelize');
const sequelize = require('../config/config');
const PlaylistHub = require('./playlistHub');

const Playlist = sequelize.define('Playlist', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  playlist_hub_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: PlaylistHub,
      key: 'id',
    },
    onDelete: 'CASCADE',
  },
  name: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  visibility: {
    type: DataTypes.ENUM('public', 'private'),
    defaultValue: 'private',
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'playlists',
  timestamps: false,
});

Playlist.associate = (models) => {
  Playlist.belongsTo(models.PlaylistHub, {
    foreignKey: 'playlist_hub_id',
    as: 'playlistHub',
  });

  Playlist.belongsToMany(models.Banni, {
    through: models.PlaylistBanni,
    foreignKey: 'playlist_id',
    otherKey: 'banni_id',
    as: 'bannis',
  });

  Playlist.belongsToMany(models.Shabad, {
    through: models.PlaylistShabad,
    foreignKey: 'playlist_id',
    otherKey: 'shabad_id',
    as: 'shabads',
  });
};

module.exports = Playlist;
