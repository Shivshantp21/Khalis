
const { DataTypes } = require('sequelize');
const sequelize = require('../config/config');

const Banni = sequelize.define('Banni', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  title: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  content: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'bannis',
  timestamps: false,
});

Banni.associate = (models) => {
  Banni.belongsToMany(models.Playlist, {
    through: models.PlaylistBanni,
    foreignKey: 'banni_id',
    otherKey: 'playlist_id',
    as: 'playlists',
  });
};

module.exports = Banni;
