
const { DataTypes } = require('sequelize');
const sequelize = require('../config/config');

const Shabad = sequelize.define('Shabad', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  title: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  content: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'shabads',
  timestamps: false,
});

Shabad.associate = (models) => {
  Shabad.belongsToMany(models.Playlist, {
    through: models.PlaylistShabad,
    foreignKey: 'shabad_id',
    otherKey: 'playlist_id',
    as: 'playlists',
  });
};

module.exports = Shabad;
