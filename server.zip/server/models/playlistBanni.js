
const { DataTypes } = require('sequelize');
const sequelize = require('../config/config');
const Playlist = require('./playlist');
const Banni = require('./banni');

const PlaylistBanni = sequelize.define('PlaylistBanni', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  playlist_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Playlist,
      key: 'id',
    },
    onDelete: 'CASCADE',
  },
  banni_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Banni,
      key: 'id',
    },
    onDelete: 'CASCADE',
  },
  chapter_order: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  added_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'playlist_bannis',
  timestamps: false,
  indexes: [
    {
      unique: true,
      fields: ['playlist_id', 'banni_id'],
    },
  ],
});

module.exports = PlaylistBanni;
