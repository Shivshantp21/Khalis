
const sequelize = require('../config/config');
const User = require('./user');
const PlaylistHub = require('./playlistHub')
const Playlist = require('./playlist');
const Banni = require('./banni');
const Shabad = require('./shabad');
const PlaylistBanni = require('./playlistBanni');
const PlaylistShabad = require('./playlistShabad');

// Initialize associations
User.hasMany(PlaylistHub, { foreignKey: 'user_id', as: 'playlistHubs', onDelete: 'CASCADE' });
PlaylistHub.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

PlaylistHub.hasMany(Playlist, { foreignKey: 'playlist_hub_id', as: 'playlists', onDelete: 'CASCADE' });
Playlist.belongsTo(PlaylistHub, { foreignKey: 'playlist_hub_id', as: 'playlistHub' });

Playlist.belongsToMany(Banni, { through: PlaylistBanni, foreignKey: 'playlist_id', otherKey: 'banni_id', as: 'bannis' });
Banni.belongsToMany(Playlist, { through: PlaylistBanni, foreignKey: 'banni_id', otherKey: 'playlist_id', as: 'playlists' });

Playlist.belongsToMany(Shabad, { through: PlaylistShabad, foreignKey: 'playlist_id', otherKey: 'shabad_id', as: 'shabads' });
Shabad.belongsToMany(Playlist, { through: PlaylistShabad, foreignKey: 'shabad_id', otherKey: 'playlist_id', as: 'playlists' });

module.exports = {
  sequelize,
  User,
  PlaylistHub,
  Playlist,
  Banni,
  Shabad,
  PlaylistBanni,
  PlaylistShabad,
};
