
const { DataTypes } = require('sequelize');
const sequelize = require('../config/config');
const Playlist = require('./playlist');
const Shabad = require('./shabad');

const PlaylistShabad = sequelize.define('PlaylistShabad', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  playlist_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Playlist,
      key: 'id',
    },
    onDelete: 'CASCADE',
  },
  shabad_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Shabad,
      key: 'id',
    },
    onDelete: 'CASCADE',
  },
  chapter_order: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  added_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
}, {
  tableName: 'playlist_shabads',
  timestamps: false,
  indexes: [
    {
      unique: true,
      fields: ['playlist_id', 'shabad_id'],
    },
  ],
});

module.exports = PlaylistShabad;
